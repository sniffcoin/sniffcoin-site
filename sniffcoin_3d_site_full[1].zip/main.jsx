import React from "react";
import ReactDOM from "react-dom/client";
import SniffCoin3DHome from "./app/page";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <SniffCoin3DHome />
  </React.StrictMode>
);