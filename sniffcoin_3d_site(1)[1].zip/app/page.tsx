import { useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Volume2 } from "lucide-react";

export default function SniffCoin3DHome() {
  useEffect(() => {
    const audio = new Audio("/sounds/sniffdog_bark.mp3");
    audio.loop = true;
    audio.volume = 0.3;
    audio.play();
  }, []);

  return (
    <div className="min-h-screen bg-purple-950 text-white p-4 relative">
      <header className="flex justify-between items-center mb-6">
        <div className="flex gap-3 items-center">
          <a href="https://x.com/Sniffsniffcoin" target="_blank" rel="noopener noreferrer">
            <img src="/icons/twitter.svg" alt="Twitter" className="w-6 h-6" />
          </a>
          <a href="https://t.me/sniffcoinclub" target="_blank" rel="noopener noreferrer">
            <img src="/icons/telegram.svg" alt="Telegram" className="w-6 h-6" />
          </a>
        </div>
        <a href="https://pump.fun/coin/4CnG6AuCqqHJgE5EAf7KytuEgVrfJCk82Ju1Gbddpump" target="_blank">
          <Button>Buy on Pump.fun</Button>
        </a>
      </header>

      <main className="flex flex-col items-center justify-center gap-8">
        <div className="w-full max-w-5xl bg-black/40 p-6 rounded-2xl shadow-xl relative">
          <img src="/3droom/sniffdog_animated.gif" alt="Sniff Dog" className="w-full rounded-xl" />
          <img src="/3droom/wall_art.jpg" alt="Wall Art" className="absolute top-4 right-4 w-24 h-24 rounded shadow-md" />
        </div>
        <div className="text-center">
          <h1 className="text-4xl font-bold mb-2">Welcome to SniffCoin HQ</h1>
          <p className="text-lg text-purple-300 max-w-xl mx-auto">
            Meet our sniffer-in-chief. He sniffs trends, tracks tokens, and occasionally barks when it's moon time. Nif sniff!
          </p>
        </div>
        <div className="flex gap-4">
          <Button variant="outline"><Volume2 className="mr-2 w-4 h-4" /> Sound On</Button>
          <Button variant="secondary">Explore SniffCoin</Button>
        </div>
      </main>
    </div>
  );
}
